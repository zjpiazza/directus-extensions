import { FieldFilter, Permission } from '@directus/types';
import { generateJoi } from '@directus/utils';

export function isAllowed(
	collection: string,
	action: Permission['action'],
	value: Record<string, any> | null,
	strict = false,
	stores?: any,
): boolean {
	if (!collection) return false;

	let permissionsStore: any;
	let userStore: any;

	if (stores) {
		permissionsStore = stores.usePermissionsStore();
		userStore = stores.useUserStore();
	} else {
		// Fallback - try to get stores, but handle if they don't exist
		try {
			const { useStores } = require('@directus/extensions-sdk');
			const storeCollection = useStores();
			userStore = storeCollection.useUserStore();
			permissionsStore = storeCollection.usePermissionsStore();
		} catch (e) {
			// If stores are not available, return false (no permission)
			return false;
		}
	}

	// In Directus 11, admin access can be on the user directly or through role
	const isAdmin =
		userStore.currentUser?.role?.admin_access === true ||
		userStore.currentUser?.admin_access === true ||
		userStore.isAdmin === true;
	if (isAdmin) return true;

	const permissions = permissionsStore.permissions;

	const permissionInfo = permissions.find(
		(permission: any) => permission.action === action && permission.collection === collection,
	);

	if (!permissionInfo) return false;
	if (!permissionInfo.fields && action !== 'share') return false;

	if (strict && action !== 'share' && permissionInfo.fields!.includes('*') === false && value) {
		const allowedFields = permissionInfo.fields;
		const attemptedFields = Object.keys(value);

		if (attemptedFields.every((field) => allowedFields!.includes(field)) === false) return false;
	}

	if (!permissionInfo.permissions || Object.keys(permissionInfo.permissions).length === 0) return true;

	const schema = generateJoi(permissionInfo.permissions as FieldFilter);

	const { error } = schema.validate(value);

	if (!error) {
		return true;
	}

	return false;
}
